var dir_0833332c427d9a36307412273bc77fe2 =
[
    [ "@babel", "dir_5b4eca07d46a437af76d6834bf7c8ada.html", "dir_5b4eca07d46a437af76d6834bf7c8ada" ],
    [ "react-is", "dir_465cb1d483839578fa3b90faacf15c51.html", null ],
    [ "react-refresh", "dir_944db6ca1e11d401ce14f62de03bbb19.html", null ],
    [ "regenerator-runtime", "dir_f2fa39eed4859b85e0135e6de016cea3.html", null ]
];