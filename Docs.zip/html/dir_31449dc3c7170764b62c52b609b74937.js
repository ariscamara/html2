var dir_31449dc3c7170764b62c52b609b74937 =
[
    [ "__init__.py", "backend_2____init_____8py.html", null ],
    [ "database.py", "database_8py.html", "database_8py" ],
    [ "fetch_themealdb_recipes.py", "fetch__themealdb__recipes_8py.html", "fetch__themealdb__recipes_8py" ],
    [ "init_db.py", "init__db_8py.html", "init__db_8py" ],
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "models.py", "models_8py.html", "models_8py" ],
    [ "populate_inventory.py", "populate__inventory_8py.html", "populate__inventory_8py" ],
    [ "recommendation_engine.py", "recommendation__engine_8py.html", "recommendation__engine_8py" ],
    [ "schemas.py", "schemas_8py.html", "schemas_8py" ]
];