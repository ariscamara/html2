var class_stats_worker =
[
    [ "StatsWorker", "class_stats_worker.html#a17dc066e104029e535d56ff2864585b0", null ],
    [ "~StatsWorker", "class_stats_worker.html#aa6d72cdc278a5911759b37b3b91a4b0f", null ],
    [ "Execute", "class_stats_worker.html#a769dc2ba398a78ac0692d0b815ecd253", null ],
    [ "OnOK", "class_stats_worker.html#a85b46d0e82674f29489e5866cae24d6f", null ],
    [ "STAT_MAX_INDEX", "class_stats_worker.html#a790c564b556be94ee5503a2041c604c8", null ],
    [ "STAT_MAXX_INDEX", "class_stats_worker.html#a13361edd237333355fb5cba0bb06ec43", null ],
    [ "STAT_MAXY_INDEX", "class_stats_worker.html#adaffcae6ab27ac00a92f8b288d760622", null ],
    [ "STAT_MEAN_INDEX", "class_stats_worker.html#aa148c1780184faf234cdcc1ad3fcd734", null ],
    [ "STAT_MIN_INDEX", "class_stats_worker.html#a8d525781b30f714ae304ab07f26fc6fc", null ],
    [ "STAT_MINX_INDEX", "class_stats_worker.html#aa41e4dd430f2968f40bfb69fa120c328", null ],
    [ "STAT_MINY_INDEX", "class_stats_worker.html#a711a8694dbb52e92a9931d22034b326a", null ],
    [ "STAT_SQ_SUM_INDEX", "class_stats_worker.html#a8ffdd51b90ddd8be406b6dc1afa856c2", null ],
    [ "STAT_STDEV_INDEX", "class_stats_worker.html#aeeafdb5a9ab3107ed0f8879fb62a147e", null ],
    [ "STAT_SUM_INDEX", "class_stats_worker.html#a948e574913412019d55cb4f5b42e281a", null ]
];