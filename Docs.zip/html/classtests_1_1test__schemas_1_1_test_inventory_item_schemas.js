var classtests_1_1test__schemas_1_1_test_inventory_item_schemas =
[
    [ "test_inventory_item_base_invalid_missing_fields", "classtests_1_1test__schemas_1_1_test_inventory_item_schemas.html#afe79e3ffe2bd41f43dcf1b9a117bda82", null ],
    [ "test_inventory_item_base_invalid_types", "classtests_1_1test__schemas_1_1_test_inventory_item_schemas.html#a83b679c88d7c88d7146a5d0a537c0052", null ],
    [ "test_inventory_item_base_valid", "classtests_1_1test__schemas_1_1_test_inventory_item_schemas.html#a7ab4083bd179f246d6e4f6f0b5204893", null ],
    [ "test_inventory_item_create_inherits_from_base", "classtests_1_1test__schemas_1_1_test_inventory_item_schemas.html#a6a9e7cc12849f9c0d4246f81536df251", null ],
    [ "test_inventory_item_full_schema", "classtests_1_1test__schemas_1_1_test_inventory_item_schemas.html#addd74634ac89bed28f4725ccae72c79f", null ],
    [ "test_inventory_item_update_all_fields", "classtests_1_1test__schemas_1_1_test_inventory_item_schemas.html#aba3aefe681fe04e7b2d532dbbc5a6cbb", null ],
    [ "test_inventory_item_update_optional_fields", "classtests_1_1test__schemas_1_1_test_inventory_item_schemas.html#ad14bc59f7c9e23a23ce63dbed8455b7b", null ]
];