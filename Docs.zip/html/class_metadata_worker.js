var class_metadata_worker =
[
    [ "MetadataWorker", "class_metadata_worker.html#ab57af7ebb6d4ab080b3596e4d6f95d67", null ],
    [ "~MetadataWorker", "class_metadata_worker.html#ac6bdcff4cd20d7f887395140fd2ac148", null ],
    [ "Execute", "class_metadata_worker.html#a8f64ee536314d48dc36d4bd905eb469e", null ],
    [ "OnOK", "class_metadata_worker.html#ac0c79882118dee511d9f25342a89c912", null ]
];