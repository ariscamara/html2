var class_pipeline_worker =
[
    [ "PipelineWorker", "class_pipeline_worker.html#a3bd86d29eeb8ee07ff80694425fdafa3", null ],
    [ "~PipelineWorker", "class_pipeline_worker.html#a419301a19bc4a3e6d3503d9dd95706e4", null ],
    [ "Execute", "class_pipeline_worker.html#a211c92807b9a3e33632e3f9b013913a9", null ],
    [ "OnOK", "class_pipeline_worker.html#ad8a643677b8645a07d70872b89dabe09", null ]
];