var dir_024231cef7c6c008215b26684207cd4f =
[
    [ "load-nyc-config", "dir_3fe958fdbeb629db849894a3748e873a.html", "dir_3fe958fdbeb629db849894a3748e873a" ],
    [ "schema", "dir_4a05ee7c3b16c5fb7b978293245c91d7.html", null ]
];