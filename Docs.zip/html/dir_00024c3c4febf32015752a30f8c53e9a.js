var dir_00024c3c4febf32015752a30f8c53e9a =
[
    [ "ansi-styles", "dir_d5de53e7eaf71c2c8e1a2d222ceb6d63.html", null ],
    [ "pretty-format", "dir_ab0c9bc9b4805d2ca4f1f139d24355f9.html", null ]
];