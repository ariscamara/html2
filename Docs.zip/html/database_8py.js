var database_8py =
[
    [ "backend.database.get_db", "namespacebackend_1_1database.html#abc8656c264d39ff84f044a2966fd5ef8", null ],
    [ "backend.database.Base", "namespacebackend_1_1database.html#abd2529d4ecaa33681dfa1ab2ccd8c64d", null ],
    [ "backend.database.DATABASE_URL", "namespacebackend_1_1database.html#a59a103af45b6af86151e138857c910af", null ],
    [ "backend.database.engine", "namespacebackend_1_1database.html#a46468e815b89fdd5a577630ccff21c70", null ],
    [ "backend.database.SessionLocal", "namespacebackend_1_1database.html#a8ba095081b8056c2d6d292836280495a", null ]
];