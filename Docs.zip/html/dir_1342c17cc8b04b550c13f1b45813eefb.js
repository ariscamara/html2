var dir_1342c17cc8b04b550c13f1b45813eefb =
[
    [ "ansi-regex", "dir_6f906e456f4840f0dd905370235654ae.html", null ],
    [ "emoji-regex", "dir_698f8fcde6da03d18282a99fef13d124.html", null ],
    [ "strip-ansi", "dir_d2195b0acb930660ef7c84c44f4d6c59.html", null ]
];