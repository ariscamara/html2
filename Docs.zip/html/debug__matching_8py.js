var debug__matching_8py =
[
    [ "debug_matching.debug_ingredient_matching", "namespacedebug__matching.html#a7be831de577e176248fc308e0ced1197", null ]
];