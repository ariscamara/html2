var dir_02d712ee44514d06f5752fb28c699d37 =
[
    [ "__init__.py", "tests_2____init_____8py.html", null ],
    [ "conftest.py", "conftest_8py.html", "conftest_8py" ],
    [ "test_main.py", "test__main_8py.html", "test__main_8py" ],
    [ "test_models.py", "test__models_8py.html", "test__models_8py" ],
    [ "test_recommendation_engine.py", "test__recommendation__engine_8py.html", "test__recommendation__engine_8py" ],
    [ "test_schemas.py", "test__schemas_8py.html", "test__schemas_8py" ]
];