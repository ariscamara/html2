var classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine =
[
    [ "test_calculate_expiration_urgency_score", "classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine.html#a0167ff00e02a78ec1b7f1722608b5432", null ],
    [ "test_calculate_ingredient_match_score_empty_recipe", "classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine.html#a75f0b334a90d66b1d1cec10ef2ac9334", null ],
    [ "test_calculate_ingredient_match_score_missing_ingredient", "classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine.html#af149e951068f6e6db69ae89e8a8e5ade", null ],
    [ "test_calculate_ingredient_match_score_perfect_match", "classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine.html#aad6e617427a321e2b56fe2ead9316320", null ],
    [ "test_get_recipe_recommendations_no_inventory", "classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine.html#a702859f57d4104e27fbaa605d260ee57", null ],
    [ "test_get_recipe_recommendations_with_exact_matches", "classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine.html#ad9553e2a0d74c0319ee2fe59fba848c0", null ],
    [ "test_normalize_ingredient_name", "classtests_1_1test__recommendation__engine_1_1_test_recommendation_engine.html#a2b8b1a1c8b7adc863231879cb747bbce", null ]
];